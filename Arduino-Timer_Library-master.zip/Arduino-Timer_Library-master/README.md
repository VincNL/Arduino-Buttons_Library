# Arduino-Timer_Library

(So called Multithreading) Simple arduino timer - used for counting time and making delay without using the delay() function that freezes the whole system.

                USING DELAY() FUNCTION MAY CAUSE THE TIMER ERRORS!!
                
Simply writed library that help you delay something while something else continue on running.

If you want to see all the functions you can use and what does every function do use the function .help(), and it will print on the serial monitor all the functions (Use Serial.begin(9600) - or any other baud rate at the setup() function).


Library written by VincNL
